﻿using MVVMbasics.Attributes;
using Core.Viewmodels;

namespace $safeprojectname$.Views
{
	[MvvmNavigationTarget(typeof(MainViewmodel))]
	public sealed partial class MainPage : BackButtonAwareBaseView
	{
		public MainPage()
		{
			this.InitializeComponent();
		}
	}
}
