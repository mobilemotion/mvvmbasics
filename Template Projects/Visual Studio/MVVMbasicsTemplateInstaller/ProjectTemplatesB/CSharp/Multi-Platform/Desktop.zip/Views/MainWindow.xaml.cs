﻿using MVVMbasics.Attributes;
using Core.Viewmodels;
using MVVMbasics.Views;

namespace $safeprojectname$.Views
{
	[MvvmNavigationTarget(typeof(MainViewmodel))]
	public partial class MainWindow : BaseView
	{
		public MainWindow()
		{
			InitializeComponent();
		}
	}
}
