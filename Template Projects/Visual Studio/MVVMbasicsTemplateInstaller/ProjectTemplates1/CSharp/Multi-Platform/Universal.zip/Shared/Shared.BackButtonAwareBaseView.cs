using Core.Viewmodels;
using MVVMbasics.Views;
#if WINDOWS_PHONE_APP
using Windows.Phone.UI.Input;
#endif

namespace $safeprojectname$.Views
{
	/// <summary>
	/// Wrapper class for MVVMbasic's BaseView that includes event handlers for the hardware back button's pressed event.
	/// If you don't want to override back button behaviour in your App, delete this class and let all Pages inherit
	/// directly from BaseView.
	/// </summary>
	public class BackButtonAwareBaseView : BaseView
    {
		/// <summary>
		/// Constructor. Registers and unregisters the hardware back button's pressed event handler.
		/// </summary>
	    public BackButtonAwareBaseView()
	    {
			Loaded += BackButtonAwareBaseView_Loaded;
#if WINDOWS_PHONE_APP
		    Loaded += (sender, args) => HardwareButtons.BackPressed += HardwareButtonsOnBackPressed;
		    Unloaded += (sender, args) => HardwareButtons.BackPressed -= HardwareButtonsOnBackPressed;
#endif
	    }

		private void BackButtonAwareBaseView_Loaded(object sender, Windows.UI.Xaml.RoutedEventArgs e)
		{
			var viewmodel = Viewmodel as NavigatorAwareBaseViewmodel;
			if (viewmodel != null)
			{
				viewmodel.UpdateCanGoBack();
			}
		}

		/// <summary>
		/// Hardware back button's pressed event handler. Calls the Viewmodel's GoBack command if applicable, or invokes
		/// the default back button behaviour otherwise.
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="args"></param>
#if WINDOWS_PHONE_APP
	    private void HardwareButtonsOnBackPressed(object sender, BackPressedEventArgs args)
	    {
			var viewmodel = Viewmodel as NavigatorAwareBaseViewmodel;
		    if (viewmodel != null)
		    {
				viewmodel.UpdateCanGoBack();
			    if (viewmodel.CanGoBack)
			    {
				    viewmodel.GoBackCommand.Execute();
				    args.Handled = true;
			    }
		    }
	    }
#endif
    }
}
