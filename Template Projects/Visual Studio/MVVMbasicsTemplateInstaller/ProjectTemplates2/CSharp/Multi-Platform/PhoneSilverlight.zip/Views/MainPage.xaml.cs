﻿using Core.Viewmodels;
using MVVMbasics.Attributes;
using MVVMbasics.Views;

namespace $safeprojectname$.Views
{
	//TODO: In the following attribute, fill in correct Viewmodel type and add file path that points to this View's
	//      XAML file (only necessary if this path differs from the View's namespace)
	[MvvmNavigationTarget(typeof (MainViewmodel))]
	public partial class MainPage : BaseView
	{
		public MainPage()
		{
			InitializeComponent();
		}
	}
}